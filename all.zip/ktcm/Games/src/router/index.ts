import { createRouter, createWebHashHistory } from "vue-router"
import Login from "../components/login.vue";
import Register from "../components/register.vue";
import dashboard from "../components/dashboard.vue";


const routes = [
  { path: "/", name: "Login", component: Login },
  { path: "/register", name: "Register", component: Register },
  { path: "/dashboard", name: "Dashboard", component: dashboard },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;
