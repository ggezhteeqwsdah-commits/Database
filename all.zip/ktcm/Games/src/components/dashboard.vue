<script setup lang="ts">
import { useRouter } from 'vue-router'


const router = useRouter()


const goTo = (page: string) => {
  if (page === 'person') router.push('/person')
  else if (page === 'department') router.push('/department')
}
</script>

<template>
  <div class="dashboard-container">
    <div class="header">
      <h1 class="title"> Dashboard</h1>
      <p class="subtitle">ระบบประเมินพนักงาน</p>
    </div>

    <!-- 🧭 กล่องใหญ่ใช้ flex แบ่งซ้ายขวา -->
    <div class="content-box">
      <!-- กล่องซ้าย -->
      <div class="box left">
        <div class="icon-circle">
          <i class="fas fa-user-check"></i>
        </div>
        <h2>ประเมินบุคคล</h2>
        <p>เมนูสำหรับการประเมินผลรายบุคคล</p>
        <button @click="goTo('person')" class="btn">ไปที่หน้าประเมินบุคคล</button>
      </div>

      <!-- กล่องขวา -->
      <div class="box right">
        <div class="icon-circle">
          <i class="fas fa-building"></i>
        </div>
        <h2>แผนก</h2>
        <p>ดูข้อมูลและจัดการแผนกทั้งหมด</p>
        <button @click="goTo('department')" class="btn">ไปที่หน้าแผนก</button>
      </div>
    </div>
  </div>
</template>



<style scoped>
/* 🌌 พื้นหลัง Gradient + Glass Effect */
.dashboard-container {
  min-height: 90vh;
  width: 100%;
  background: linear-gradient(135deg, #0a0a0a, #1d1919, #533737);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-family: 'Prompt', sans-serif;
  color: #fff;
  padding: 2rem;
}

/* 🏷️ ส่วนหัว */
.header {
  text-align: center;
  margin-bottom: 2.5rem;
}

.title {
  font-size: 3rem;
  font-weight: 700;
  color: #42b883;
  letter-spacing: 1px;
}

.subtitle {
  font-size: 1.25rem;
  color: #dcdcdc;
  margin-top: 0.3rem;
}

/* 🧩 กล่องเนื้อหา */
.content-box {
  display: flex;
  justify-content: center;
  align-items: stretch;
  gap: 2.5rem;
  width: 85%;
  max-width: 1100px;
  flex-wrap: nowrap;
}

/* 🪟 การ์ดซ้ายขวา */
.box {
  flex: 1;
  min-width: 320px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 20px;
  padding: 3rem 2rem;
  text-align: center;
  backdrop-filter: blur(15px);
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
  transition: all 0.35s ease;
}

.box:hover {
  transform: translateY(-10px);
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6);
}

/* 🪶 หัวข้อในการ์ด */
.box h2 {
  font-size: 1.8rem;
  color: #42b883;
  margin-bottom: 0.5rem;
}

.box p {
  font-size: 1.1rem;
  color: #e8e8e8;
}

/* 🔘 ปุ่ม */
.btn {
  margin-top: 1.8rem;
  padding: 0.9rem 1.5rem;
  border: none;
  border-radius: 12px;
  background: linear-gradient(90deg, #42b883, #2c9e6f);
  color: white;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn:hover {
  background: linear-gradient(90deg, #2c9e6f, #42b883);
  transform: scale(1.05);
}

/* 📱 Responsive */
@media (max-width: 768px) {
  .content-box {
    flex-direction: column;
    align-items: center;
  }

  .box {
    width: 95%;
  }

  .title {
    font-size: 2.4rem;
  }
}
</style>