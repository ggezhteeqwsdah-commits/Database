<script setup>
import { ref } from "vue"
import { useRouter } from "vue-router"

const router = useRouter();
const username = ref("");
const password = ref("");
const message = ref("");
const error = ref("");

const handleLogin = async () => {
  if (!username.value || !password.value) {
    error.value = "กรุณากรอกชื่อผู้ใช้และรหัสผ่าน";
    return;
  }

  const res = await fetch("http://localhost/ktcm/games/api/login.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      username: username.value,
      password: password.value,
    }),
  });

  const data = await res.json();
  if (data.success) {
    message.value = data.message;
    error.value = "";
    router.push("/dashboard"); // ไปหน้าหลัก
  } else {
    error.value = data.message;
    message.value = "";
  }
};

const goTo = (page) => {
  if (page === "register") router.push("/register");
};
</script>

<template>
  <div class="login-page">
    <div class="login-card">
      <h1 class="title">Login</h1>
      <p class="subtitle">ระบบประเมินบุคลากร</p>

      <form @submit.prevent="handleLogin" class="form">
        <div class="form-group">
          <label for="username">ชื่อผู้ใช้</label>
          <input id="username" v-model="username" type="text" placeholder="กรอกชื่อผู้ใช้" class="input" />
        </div>

        <div class="form-group">
          <label for="password">รหัสผ่าน</label>
          <input id="password" v-model="password" type="password" placeholder="กรอกรหัสผ่าน" class="input" />
        </div>

        <button type="submit" class="btn">เข้าสู่ระบบ</button>

        <p v-if="error" class="error">{{ error }}</p>
        <p v-if="message" class="success">{{ message }}</p>
      </form>

      <p class="footer">
        ยังไม่มีบัญชี?
        <button @click="goTo('register')" id="Res">สมัครสมาชิก</button>
      </p>
    </div>
  </div>
</template>

<style scoped>
#Res {
  background: rgba(63, 63, 63, 0);
  color: #17da7f;

}
/* (คัดส่วนสไตล์ของคุณไว้ตามเดิม) */
.login-page {
  height: 100vh;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, #0a0a0a, #121212, #1b1b1b);
  font-family: 'Inter', sans-serif;
  padding: 2rem;
  color: #fff;
  overflow: hidden;
}

/* กล่องฟอร์ม */
.login-card {
  background: rgba(255, 255, 255, 0.12);
  border-radius: 24px;
  padding: 4rem 5rem;
  width: 100%;       /* ขยายเต็ม container */
  max-width: 800px;  /* เพิ่มจากเดิม 650px ให้ใหญ่ขึ้น */
  text-align: center;
  backdrop-filter: blur(20px);
  box-shadow: 0 12px 48px rgba(0, 0, 0, 0.55);
  color: #fff;
  transition: transform 0.3s, box-shadow 0.3s;
}

.login-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.65);
}

/* หัวข้อ */
.title {
  font-size: 2.8rem;
  color: #42b883;
  font-weight: 800;
  margin-bottom: 0.5rem;
}
.subtitle {
  font-size: 1.2rem;
  color: #fdfdffff;
  margin-bottom: 2.2rem;
}

/* ฟอร์ม */
.form-group {
  margin-bottom: 1.8rem;
  text-align: left;
}
label {
  display: block;
  margin-bottom: 0.4rem;
  color: #bbb;
  font-size: 1.05rem;
}
.input {
  width: 90%;
  padding: 0.8rem 1rem;
  border-radius: 12px;
  border: 1px solid transparent;
  font-size: 1.1rem;
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
  transition: all 0.3s ease;
}
.input:focus {
  border-color: #42b883;
  background: rgba(255, 255, 255, 0.25);
  outline: none;
}

/* ปุ่ม */
.btn {
  width: 100%;
  margin-top: 1rem;
  padding: 0.9rem;
  border: none;
  border-radius: 10px;
  background: linear-gradient(90deg, #42b883, #2c9e6f);
  color: white;
  font-size: 1.2rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
}
.btn:hover:not(:disabled) {
  background: linear-gradient(90deg, #2c9e6f, #42b883);
  transform: translateY(-2px);
}
.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* Loading spinner */
.loader {
  width: 22px;
  height: 22px;
  border: 3px solid #fff;
  border-top: 3px solid transparent;
  border-radius: 50%;
  display: inline-block;
  animation: spin 1s linear infinite;
}
@keyframes spin {
  100% {
    transform: rotate(360deg);
  }
}

/* ข้อความแจ้งเตือน */
.error {
  color: #ff6b6b;
  margin-top: 1.2rem;
  font-size: 1.05rem;
}
.success {
  color: #42b883;
  margin-top: 1.2rem;
  font-size: 1.05rem;
}

/* ลิงก์ */
.footer {
  margin-top: 2.2rem;
  color: #ccc;
  font-size: 1rem;
}
.link {
  color: #42b883;
  text-decoration: none;
  font-weight: 600;
}
.link:hover {
  text-decoration: underline;
}

/* เอฟเฟกต์ fade */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.4s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>