<template>
  <div class="app">
    <router-view />
  </div>
</template>
