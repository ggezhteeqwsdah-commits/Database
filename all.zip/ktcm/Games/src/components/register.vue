<script setup>
import { ref } from "vue"
import { useRouter } from "vue-router"

const router = useRouter();
const username = ref("");
const email = ref("");
const password = ref("");
const confirmPassword = ref("");
const department = ref("");
const message = ref("");
const error = ref("");
const success = ref("");

const departments = ["IT", "บัญชี", "การตลาด", "บุคคล"];

const handleRegister = async () => {
  try {
    // ตรวจสอบข้อมูล
    if (!username.value || !email.value || !password.value || !confirmPassword.value || !department.value) {
      error.value = "กรุณากรอกข้อมูลให้ครบถ้วน";
      success.value = "";
      return;
    }

    if (password.value !== confirmPassword.value) {
      error.value = "รหัสผ่านไม่ตรงกัน";
      success.value = "";
      return;
    }

    // ส่งข้อมูลไปยัง API
    const res = await fetch("http://localhost/ktcm/games/api/register.php", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        username: username.value,
        email: email.value,
        password: password.value,
        department: department.value,
      }),
    });

    const data = await res.json();
    if (data.success) {
      success.value = data.message;
      error.value = "";
      // รอ 2 วินาทีแล้วไปหน้า login
      setTimeout(() => {
        router.push("/");
      }, 2000);
    } else {
      error.value = data.message;
      success.value = "";
    }
  } catch (err) {
    console.error(err);
    error.value = "เกิดข้อผิดพลาดในการเชื่อมต่อ";
    success.value = "";
  }
};

const goTo = (page) => {
  if (page === "login") router.push("/");
};
</script>

<template>
  <div class="register-page">
    <div class="register-card">
      <h1 class="title">สมัครสมาชิก</h1>
      <p class="subtitle">สร้างบัญชีใหม่เพื่อเข้าสู่ระบบ</p>

      <form @submit.prevent="handleRegister" class="form">
        <div class="form-group">
          <label for="username">ชื่อผู้ใช้</label>
          <input id="username" v-model="username" type="text" class="input" placeholder="กรอกชื่อผู้ใช้" />
        </div>

        <div class="form-group">
          <label for="email">อีเมล</label>
          <input id="email" v-model="email" type="email" class="input" placeholder="กรอกอีเมล" />
        </div>

        <div class="form-group">
          <label for="department">แผนก</label>
          <select id="department" v-model="department" class="input">
            <option value="" disabled>เลือกแผนก</option>
            <option v-for="dept in departments" :key="dept" :value="dept">{{ dept }}</option>
          </select>
        </div>

        <div class="form-group">
          <label for="password">รหัสผ่าน</label>
          <input id="password" v-model="password" type="password" class="input" placeholder="กรอกรหัสผ่าน" />
        </div>

        <div class="form-group">
          <label for="confirmPassword">ยืนยันรหัสผ่าน</label>
          <input id="confirmPassword" v-model="confirmPassword" type="password" class="input" placeholder="ยืนยันรหัสผ่าน" />
        </div>

        <button type="submit" class="btn">สมัครสมาชิก</button>

        <p v-if="error" class="error">{{ error }}</p>
        <p v-if="success" class="success">{{ success }}</p>
      </form>

      <p class="footer">
        มีบัญชีอยู่แล้ว?
        <button @click="goTo('login')" id="link">เข้าสู่ระบบ</button>
      </p>
    </div>
  </div>
</template>

<style scoped>
/* ใช้ดีไซน์เดียวกับหน้า login */
.register-page {
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, #0a0a0a, #121212, #1b1b1b);
  color: #fff;
  font-family: 'Inter', sans-serif;
}

.register-card {
  background: rgba(221, 204, 204, 0.12);
  border-radius: 24px;
  padding: 3rem 4rem;
  width: 90%;
  max-width: 700px;
  text-align: center;
  backdrop-filter: blur(20px);
  box-shadow: 0 12px 48px rgba(0, 0, 0, 0.55);
}

.title {
  font-size: 2.8rem;
  color: #42b883;
  font-weight: 800;
  margin-bottom: 0.5rem;
}

.subtitle {
  font-size: 1.2rem;
  margin-bottom: 2rem;
}

.form-group {
  margin-bottom: 1.5rem;
  text-align: left;
}

label {
  display: block;
  color: #bbb;
  margin-bottom: 0.3rem;
}

.input {
  width: 100%;
  padding: 0.8rem 1rem;
  border-radius: 12px;
  border: 1px solid transparent;
  background: rgba(213, 216, 211, 0.15);
  
  font-size: 1rem;
  transition: 0.3s;
}

.input:focus {
  border-color: #42b883;
  outline: none;
  background: rgba(255, 255, 255, 0.25);
}

.btn {
  width: 100%;
  margin-top: 1rem;
  padding: 0.8rem;
  border: none;
  border-radius: 10px;
  background: linear-gradient(90deg, #42b883, #2c9e6f);
  color: #fff;
  font-size: 1.2rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn:hover {
  transform: translateY(-2px);
  background: linear-gradient(90deg, #2c9e6f, #42b883);
}

.error {
  color: #ff6b6b;
  margin-top: 1rem;
}

.success {
  color: #42b883;
  margin-top: 1rem;
}

.footer {
  margin-top: 2rem;
  color: #ccc;
}

#link {
  color: #42b883;
  text-decoration: none;
  font-weight: 600;
}
#link:hover {
  text-decoration: underline;
}
</style>