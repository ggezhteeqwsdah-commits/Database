<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "ktcm_db"; // <- เปลี่ยนให้ตรงกับชื่อ database ที่คุณสร้าง

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
