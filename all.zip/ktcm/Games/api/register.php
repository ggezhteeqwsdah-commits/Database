<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

include("db.php");

// ตรวจสอบว่าเป็น OPTIONS request หรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

// ตรวจสอบว่ามีข้อมูลครบหรือไม่
if (!isset($data["username"]) || !isset($data["email"]) || !isset($data["password"]) || !isset($data["department"])) {
    echo json_encode(["success" => false, "message" => "กรุณากรอกข้อมูลให้ครบถ้วน"]);
    exit();
}

// ตรวจสอบว่า username ซ้ำหรือไม่
$check_sql = "SELECT * FROM users WHERE username = ? OR email = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("ss", $data["username"], $data["email"]);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "ชื่อผู้ใช้หรืออีเมลนี้ถูกใช้งานแล้ว"]);
    exit();
}

$username = $data["username"];
$email = $data["email"];
$password = password_hash($data["password"], PASSWORD_BCRYPT);
$department = $data["department"];

$sql = "INSERT INTO users (username, email, password, department) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $username, $email, $password, $department);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "สมัครสมาชิกสำเร็จ!"]);
} else {
    echo json_encode(["success" => false, "message" => "เกิดข้อผิดพลาดในการบันทึกข้อมูล"]);
}

$stmt->close();
$conn->close();
?>
